package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.MyConnection;
import entities.Produit;
import entities.User;

public class UserDAO implements IUserDao{

	
	
	
	
	public UserDAO() {
		
	}

	@Override
	public User getUserByLogin(String login) {
		User u=null;
		MyConnection mc = new MyConnection();

		try {
			
			PreparedStatement statement =mc.getConnection().prepareStatement( "select * from user where login='"+login+"'");
			ResultSet resultat=statement.executeQuery();
			
			
			while(resultat.next()) {
				
				u=new User();
				u.setLogin(resultat.getString(1));
				u.setMdp(resultat.getString(2));
				
			
			}
		}
		catch (SQLException e) {

		e.printStackTrace();
		}
		return u;
		
	}

	@Override
	public void inscription(User u) {
		MyConnection mc = new MyConnection();
		try {
			
			PreparedStatement statement =mc.getConnection().prepareStatement( "INSERT INTO user VALUES (?, ?)");
			
			statement.setString(1, u.getLogin());
			statement.setString(2, u.getMdp());
			
			statement.executeUpdate();
			mc.getConnection().setAutoCommit(false);
			mc.getConnection().commit();

	}
	 catch (SQLException e) {
		
		e.printStackTrace();
	}
	}

}
