package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Connection.MyConnection;
import entities.Produit;

public class ProduitDao implements IProduitDao {

	@Override
	public void ajouterProduit(Produit p) {
	
		MyConnection mc = new MyConnection();
		try {
			
			PreparedStatement statement =mc.getConnection().prepareStatement( "INSERT INTO produit VALUES (?, ?,?,?)");
			
			statement.setString(1, p.getCodeProduit());
			statement.setString(2, p.getNomProduit());
			statement.setFloat(3, p.getPrixProduit());
			statement.setString(4, p.getDateFabrication());
			statement.executeUpdate();
			mc.getConnection().setAutoCommit(false);
			mc.getConnection().commit();

	}
	 catch (SQLException e) {
		
		e.printStackTrace();
	}
		
		
	}

	@Override
	public List<Produit> afficherProduit() {
		
		List<Produit> produits=new ArrayList<>();
		MyConnection mc = new MyConnection();

		try {
			
			PreparedStatement statement =mc.getConnection().prepareStatement( "select * from produit");
			ResultSet resultat=statement.executeQuery();
			
			
			while(resultat.next()) {
				
				Produit p=new Produit();
				p.setCodeProduit((String)resultat.getString(1));
				p.setNomProduit((String)resultat.getString(2));
				p.setPrixProduit((Float)resultat.getFloat(3));
				p.setDateFabrication((String)resultat.getString(4));
				produits.add(p);
				
			
			}
		}
		catch (SQLException e) {

		e.printStackTrace();
		}
		return produits;
	}

}
