package dao;

import entities.User;

public interface IUserDao {
	
	public User getUserByLogin(String login);
    public void inscription(User u);
}
