package dao;

import java.util.List;

import entities.Produit;

public interface IProduitDao {
	
	public void ajouterProduit(Produit p);
	public List<Produit> afficherProduit();
	


}
