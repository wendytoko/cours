package service;

import entities.User;

public interface IUserService {
	
	public User getUserByLogin(String login);
    public void inscription(User u);

}
