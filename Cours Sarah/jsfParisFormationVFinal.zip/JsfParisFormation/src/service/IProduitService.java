package service;

import dao.IProduitDao;

public interface IProduitService extends IProduitDao {

}
