package service;

import java.util.List;

import dao.ProduitDao;
import entities.Produit;

public class ProduitService implements IProduitService {

	private ProduitDao dao;
	
    public ProduitService() {
    	dao=new ProduitDao();
	}

	@Override
	public void ajouterProduit(Produit p) {
		dao.ajouterProduit(p);
		
	}

	@Override
	public List<Produit> afficherProduit() {
		
		return dao.afficherProduit();
	}

	
}
