package service;

import dao.IUserDao;
import dao.UserDAO;
import entities.User;


public class UserService implements IUserService {

	
	private UserDAO dao;
	
	
	
	public UserService() {
		dao=new UserDAO();
	}

	@Override
	public User getUserByLogin(String login) {
		
		return dao.getUserByLogin(login);
	}

	@Override
	public void inscription(User u) {
		dao.inscription(u);
		
	}

}
