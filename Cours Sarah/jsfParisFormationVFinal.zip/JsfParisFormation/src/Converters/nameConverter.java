package Converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

//@FacesConverter("Converters.nameConverter")
public class nameConverter implements Converter{

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) {
		String valueConverted=value.toString().toUpperCase();
		System.out.println("test"+valueConverted);
		return valueConverted;
	
	}

	@Override
	public String getAsString(FacesContext ctx, UIComponent cpmt, Object value) {
		
		return null;
	}

}
