package managedBeans;

import java.io.IOException;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import entities.User;
import service.UserService;





public class UserManagedBean {
	
	private User usermodel;
	private UserService service;
	

	public UserManagedBean() {
		usermodel=new User();
		service=new UserService();
	}
	
	public void inscrire() {
		User u=service.getUserByLogin(usermodel.getLogin());
		if(u==null) {
		service.inscription(usermodel);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
				"Succ�s inscription", "Vous �tes inscrit !"));
		}else {
			
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL,
					"Erreur inscription", "Vous �tes d�j� inscrit !"));
			
		}
	}
	
	
	public void login() throws IOException {

		User user=service.getUserByLogin(usermodel.getLogin());
		if (user!=null && user.getMdp().equals(usermodel.getMdp())) {
			
			// cr�er la session
			HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext()
					.getSession(false);
			// r�cup�rer le login de l'utilisateur
			session.setAttribute("login", usermodel.getLogin());
			// rediriger vers hello.xhtml

			FacesContext fContext = FacesContext.getCurrentInstance();
			ExternalContext extContext = fContext.getExternalContext();
			extContext.redirect(extContext.getRequestContextPath() + "/hello.xhtml");
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Erreur authentification", "V�rifier vos identifiants"));

		}
	}

	public void logout() {
		FacesContext ctx=FacesContext.getCurrentInstance();
		ExternalContext extContext = ctx.getExternalContext();
		extContext.invalidateSession();
		try {
			extContext.redirect(extContext.getRequestContextPath() + "/login.xhtml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	
	public User getUsermodel() {
		return usermodel;
	}

	public void setUsermodel(User usermodel) {
		this.usermodel = usermodel;
	}
	
	

}
