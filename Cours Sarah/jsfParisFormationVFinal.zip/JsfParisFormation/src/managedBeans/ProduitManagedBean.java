package managedBeans;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import Connection.MyConnection;
import entities.Produit;
import service.ProduitService;
import java.util.List;

public class ProduitManagedBean {
	
	private String nomProduit;
	private float prix;
	private String dateFabrication;
	private String codeProduit;
	private ProduitService service=new ProduitService();
	private List<Produit> produits=new ArrayList<>();
	private List<String> images;
	
	public ProduitManagedBean() {
		images=new ArrayList<>();
		for(int i=1;i<4;i++) {
			
			images.add("prod"+i+".jpg");
		}
	}
	
	public void ajouter() {
		Produit p=new Produit(codeProduit,nomProduit,prix,dateFabrication);
		service.ajouterProduit(p);
		
		FacesContext fContext = FacesContext.getCurrentInstance();
	    fContext.addMessage(null, new FacesMessage("Produit ajout�:" ));
		
	}
	public void redirectToadd() throws IOException{
		
		FacesContext fcontex = FacesContext.getCurrentInstance();
        ExternalContext externcontext=fcontex.getExternalContext();
        externcontext.redirect(externcontext.getRequestContextPath()+ "/addProduct.xhtml");
	
	}

	public void redirectToList() throws IOException {

		FacesContext fcontex = FacesContext.getCurrentInstance();
		ExternalContext externcontext = fcontex.getExternalContext();
		externcontext.redirect(externcontext.getRequestContextPath() + "/afficherProduis.xhtml");

	}

	public void redirectToHome() throws IOException {

		FacesContext fcontex = FacesContext.getCurrentInstance();
		ExternalContext externcontext = fcontex.getExternalContext();
		externcontext.redirect(externcontext.getRequestContextPath() + "/hello.xhtml");

	}
	public String getNomProduit() {
		return nomProduit;
	}
	public void setNomProduit(String nomProduit) {
		this.nomProduit = nomProduit;
	}
	public float getPrix() {
		return prix;
	}
	public void setPrix(float prix) {
		this.prix = prix;
	}

	public String getDateFabrication() {
		return dateFabrication;
	}

	public void setDateFabrication(String dateFabrication) {
		this.dateFabrication = dateFabrication;
	}

	public String getCodeProduit() {
		return codeProduit;
	}

	public void setCodeProduit(String codeProduit) {
		this.codeProduit = codeProduit;
	}

	public List<Produit> getProduits() {
		return service.afficherProduit();
	}

	public void setProduits(List<Produit> produits) {
		this.produits = produits;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

}
