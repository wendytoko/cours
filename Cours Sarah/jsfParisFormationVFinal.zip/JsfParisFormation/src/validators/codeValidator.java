package validators;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class codeValidator implements Validator{

	@Override
	public void validate(FacesContext ctx, UIComponent cpmt, Object value) throws ValidatorException {
		System.out.println("test");
		if(!value.toString().startsWith("P")) {
			System.out.println(value.toString());
			FacesMessage msg = 
					new FacesMessage("Erreur de validation du code", 
							"le code doit commencer par P");
				msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				throw new ValidatorException(msg);
		}
	}

}
