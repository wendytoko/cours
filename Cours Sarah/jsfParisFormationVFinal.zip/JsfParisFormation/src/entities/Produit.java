package entities;

public class Produit {
	
	private String codeProduit;
	private String nomProduit;
	private float prixProduit;
	private String dateFabrication;
    
	public Produit() {
		
	}

	public Produit(String codeProduit, String nomProduit, float prixProduit, String dateFabrication) {
		super();
		this.codeProduit = codeProduit;
		this.nomProduit = nomProduit;
		this.prixProduit = prixProduit;
		this.dateFabrication = dateFabrication;
	}

	public String getCodeProduit() {
		return codeProduit;
	}

	public void setCodeProduit(String codeProduit) {
		this.codeProduit = codeProduit;
	}

	public String getNomProduit() {
		return nomProduit;
	}

	public void setNomProduit(String nomProduit) {
		this.nomProduit = nomProduit;
	}

	public float getPrixProduit() {
		return prixProduit;
	}

	public void setPrixProduit(float prixProduit) {
		this.prixProduit = prixProduit;
	}

	public String getDateFabrication() {
		return dateFabrication;
	}

	public void setDateFabrication(String dateFabrication) {
		this.dateFabrication = dateFabrication;
	}
	
}
